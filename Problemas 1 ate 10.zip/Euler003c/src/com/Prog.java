
package com;

public class Prog {
    
    int number;
    
    protected void masterProg() {
        methodOne();
    }
    
    protected void methodOne() {
        
    }
}
