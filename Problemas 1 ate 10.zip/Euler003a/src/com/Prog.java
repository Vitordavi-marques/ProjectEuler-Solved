
package com;

public class Prog {
    
    long start, end;
    long numberLimit = 600851475143L;
    long startingPoint = 300425737571L;
    int resto;
    boolean reseta = true;
    
    protected void masterProg() {
        start = System.currentTimeMillis();
        methodOne();
        checkRunTime();
    }
    
    protected void methodOne() {
        
        while (reseta) {
            
            if (numberLimit % startingPoint == 0) {
                if (checkIfPrime(startingPoint)) {
                    reseta = false;
                    //System.out.println(startingPoint);
                } else {
                    nextPrime();
                }
            } else {
                nextPrime();
            }
            
        }
    }
    
    protected void nextPrime() {
        resto = (int) (startingPoint % 10);
        //System.out.println(resto);
        
        startingPoint = startingPoint - 2;
        
        if (resto == 7) {
            startingPoint = startingPoint - 2;
        }
    }
    
    protected boolean checkIfPrime(long x) {
        boolean y = false;
        
        return y;
    }
}
