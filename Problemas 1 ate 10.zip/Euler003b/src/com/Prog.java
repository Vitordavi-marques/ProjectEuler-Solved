
package com;

public class Prog {
    
    long start, end;
    long numberLimit = 600851475143L;
    long actualPrime = 2;
    long newNumber;
    
    protected void masterProg() {
        methodOne();
    }
    
    protected void methodOne() {
        
        
    }
    
    protected void nextPrime() {
        newNumber = actualPrime + 1;
        boolean resetaPrime = true;
        
        for (int cont=1; cont<= Math.floor(newNumber/2); cont++) {
            
            if (resetaPrime) {
                if (newNumber % cont == 0) {
                    resetaPrime = false;
                }
            }
        }
    }
}
