
public class Main {
    
    public static void main(String[] args) {
        Prog prog = new Prog();
        prog.methodOne();
    }
}
