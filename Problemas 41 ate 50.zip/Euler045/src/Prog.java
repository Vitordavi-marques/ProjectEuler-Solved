
public class Prog {
    int l = 1;
    protected void mP() {
        System.out.println(tN(l*285));
        System.out.println(pN(l*165));
        System.out.println(hN(l*143));
    }
    
    protected int tN(int n) {
        return ((n*(n+1))/2);
    }
    
    protected int pN(int n) {
        return ((n*((3*n)-1))/2);
    }
    
    protected int hN(int n) {
        return (n*((2*n)-1));
    }
}
