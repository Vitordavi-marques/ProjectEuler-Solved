
public class Prog {
    
    int d = 5;
    
    protected void mP() {
        int total = 0;
        for (int e=2;e<=(6*( (int) (Math.pow(9, 5)) ));e++) {
            if (checkIfA(e)) {
                total = total + e;
                System.out.println(e);
            }
        }
        
        System.out.println("");
        System.out.println(total);
    }
    
    protected boolean checkIfA(int n) {
        String s = String.valueOf(n);
        int[] di = new int[s.length()];
        int sum = 0;
        
        for (int c=0;c<s.length();c++) {
            di[c] = Integer.parseInt(s.substring(c,c+1));
            sum = sum + ((int) (Math.pow(di[c], d)));
        }
        
        return (sum==n);
    }
}

/*
    protected int nChooseP(int n, int p) {
        //C(n,p) = n! / p! * (n-p)!
        return (nFac(n)) / (nFac(p) * (nFac(n-p)));
    }
    
    protected int nFac(int n) {
        int m=1;
        for (int c=n;c>=2;c--) {
            m = m*c;
        }
        return m;
    }
    */