
package euler038;

public class Euler038 {

    public static void main(String[] args) {
        Prog prog = new Prog();
        prog.mP();
    }
    
}
