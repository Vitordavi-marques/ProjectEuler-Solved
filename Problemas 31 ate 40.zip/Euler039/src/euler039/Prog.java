
package euler039;

public class Prog {
    
    int k = 0;
    int kM = 0;
    int pA = 0;
    
    protected void mP() {
        for (int p=3;p<=1000;p++) {
            k=0;
            checkForP(p);
            pA = (k>kM) ? p : pA;
            kM = (k>kM) ? k : kM;
        }
        System.out.println(pA);
    }
    
    protected void doBruteForce() {
        
    }
    
    protected void checkForP(int p) {
        for (int a=1;a<=((int)Math.ceil((p-3)/3));a++) {
            
            for (int b=1;b<=((int)(Math.ceil((p-a)/2)));b++) {
                findPyTr(a,b,p);
            }
        }
    }
    
    protected void findPyTr(int a, int b, int s) {
        int c = ((s - a) - b);
        if (checkIfTriplet(a,b,c)) {
            k++;
            //System.out.println("Solução "+k+" para p="+s + ". ("+a+","+b+","+c+").");
        }
    }
    
    protected boolean checkIfTriplet(int a,int b, int c) {
        return ((((((int)(Math.pow(a, 2))) + ((int)(Math.pow(b, 2))) == ((int)(Math.pow(c, 2)))) && (a<b)) && (b<c)) && (a>0));
    }
}

//a2 + b2 = c2
//a+b+c=s
//c = s-a-b





