
package euler039;

public class Euler039 {
    
    public static void main(String[] args) {
        Prog prog  = new Prog();
        prog.mP();
    }
}
