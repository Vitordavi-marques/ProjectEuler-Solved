
public class Prog {
    
    int mN = 1;
    int mD = 1;
    
    protected void mP() {
        for (int i=10;i<=98;i++) {
            for (int j=i+1;j<=99;j++) {
                checkIfTrivial(i,j);
            }
        }
        System.out.println(mN+"/"+mD);
    }
    
    protected void checkIfTrivial(int num, int den) {
        
        if ((LD(num)==FD(den)) && (LD(den)!=0)) {
            
            double z = ( ((double) FD(num)) / ((double)LD(den)) );
            
            if (z== ((double) num / (double) den)) {
                System.out.println("Funciona pra "+num+"/"+den);
                mN = mN*num;
                mD = mD*den;
            }
            
        }
    }
    
    protected int FD(int a) {
        return (int) Math.floor(a/10);
    }
    
    protected int LD(int a) {
        return a%10;
    }
}
