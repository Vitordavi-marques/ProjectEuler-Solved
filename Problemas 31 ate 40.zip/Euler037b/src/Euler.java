
public class Euler {
    
    protected boolean checkIfPrime(int n) {
        boolean b = true;
        boolean rs = true;
        if ((((n%2==0) && (n>2)) || ((n%5==0) && (n>5))) || (n==1)) {
            b = false;
        }
        if (((n%2==1) && (n>5))) {
            for (int c=2;c<=Math.ceil( Math.sqrt(n) );c++) {
                if (rs) {
                    if (n%c == 0) {
                        rs = false;
                        b = false;
                    }
                }
            }
        }
        return b;
    }
    
    protected int nFactorial(int n) {
        int m = 1;
        for (int c=2;c<=n;c++) {
            m=m*c;
        }
        return m;
    }
    
    protected void generatePrimes(int lo, int lf) {
        System.out.print("{");
        for (int c=lo;c<=lf;c++) {
            if (c%5000==0) {
                System.out.println("");
            }
            if (checkIfPrime(c)) {
                System.out.print(c);
                
                if (c!=lf) {
                    System.out.print(", ");
                } else {
                    System.out.print("}");
                }
            }
        }
    }
    
    protected int getFirstDigit(int n) {
        return Integer.parseInt(Integer.toString(n).substring(0,1));
    }
    
    protected int getLastDigit(int n) {
        return Integer.parseInt(Integer.toString(n).substring(Integer.toString(n).length()-1,Integer.toString(n).length()));
    }
}
